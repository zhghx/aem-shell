use(function () {
  'use strict';

  response.setHeader('content-type', 'application/xml; charset=utf-8');

  return;
});