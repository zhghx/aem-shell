use(function () {
    'use strict';
});
